This directory and some tests ("opt zxnext", "opt dirbol") here use 'space' character
in file names to exercise the testing script, do not simplify the names by renaming them.
