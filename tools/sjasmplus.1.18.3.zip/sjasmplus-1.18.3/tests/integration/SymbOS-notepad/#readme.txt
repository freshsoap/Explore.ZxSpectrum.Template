---------------------------------------
sjasmplus related info:
This test is based on "notepad" app
written by Prodatron, downloaded from
http://www.symbos.org/

I believe the license of the sources
is "Public Domain", but I had difficult
time to confirm this, as the sources
don't contain license info.

The sources were just adapted to
sjasmplus syntax and are here as
example of sjasmplus syntax and
test-facility to verify it does
produce correct binary.

---------------------------------------
Original "#readme.txt":

======================================= 
*     ___       ____  _    ___  ___   * 
*    /__  /__/ / / / /_\  /  / /__    * 
*   ___/ ___/ /   / /__/ /__/ ___/    * 
*       SYMBIOSIS MULTITASKING        * 
*       BASED OPERATING SYSTEM        * 
======================================= 
             N O T E P A D 
             (Text editor) 
--------------------------------------- 
  Author: Prodatron/SymbiosiS 
 Version: 1.2 
    Date: 19.10.2014 
Requires: SymbOS 2.1 
  Memory: 128K (or more) 
--------------------------------------- 
[...] 
--------------------------------------- 
This archive contains the following 
files: 
....................................... 
notepad.exe    Executable 
notepad.dat    additional file(s) 
notepad.hlp    Help 
sources\       Source codes 
Notepad-CPC.DSK 
               disk image (CPC or PCW) 
Notepad-FAT.DSK 
               disk image (MSX or EP) 
--------------------------------------- 
For additional information please visit 
         http://www.symbos.org 
======================================= 
