# This is *source* directory

If you are looking for **windows executable**, go to
[https://github.com/z00m128/sjasmplus/releases/latest](https://github.com/z00m128/sjasmplus/releases/latest)
and look for clickable **sjasmplus-\*.win.zip** under the description of current release,
in the **Assets** area.

You may still consider downloading also "Source code (zip)" archive, which contains
256+ tests used to verify correctness of the binary, which may be also checked as examples
of usage of various features of sjasmplus (few of the tests, especially those in folders
`tests/docs_examples`, `tests/lua_examples` and `tests/macro_examples`, are particularly
focused to be examples of real usage, instead of being "just test").
