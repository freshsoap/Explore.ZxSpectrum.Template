
#include "lua.h"
#include "lualib.h"
#include "lauxlib.h"

int luaopen_pack(lua_State *L);

