/*
** Lua binding: sjasm
** Generated automatically by tolua++-1.0.92 on 11/06/08 00:50:38.
*/

/* Exported function */
TOLUA_API int  tolua_sjasm_open (lua_State* tolua_S);

