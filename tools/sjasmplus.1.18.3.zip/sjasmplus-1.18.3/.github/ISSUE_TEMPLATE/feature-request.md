---
name: feature request
about: suggest an idea for SjASMPlus
title: ''
labels: enhancement
assignees: ''

---

<!--
Thank you for suggesting an idea to make SjASMPlus better.
Please fill in as much of the template below as you're able:
-->

**Is your feature request related to a problem?**
<!-- Please describe the problem you are trying to solve -->


**Describe the suggested solution:**
<!-- Please describe the desired behavior -->
