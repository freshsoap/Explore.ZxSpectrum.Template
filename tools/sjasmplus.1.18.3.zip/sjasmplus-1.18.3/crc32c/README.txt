this is copy (and hand-edited) of project:
 https://github.com/robertvazan/crc32c-hw

LICENSE: zlib license https://opensource.org/licenses/Zlib

Changes:
 removed the HW variant as this will be used mostly for small amount of data
 and a lot on older CPUs and outside of x86 world, so the benefits of HW x86
 variant are minimal for sjasmplus project.
